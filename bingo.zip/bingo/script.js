function generateRandomBoard() {
    const bingoNumbers = Array.from({ length: 25 }, (_, index) => index + 1);
    shuffleArray(bingoNumbers);
    displayBoard(bingoNumbers);
}

function displayBoard(numbers) {
    const board = document.getElementById('bingo-board');
    board.innerHTML = '';

    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 5; j++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.textContent = numbers[i * 5 + j];
            cell.addEventListener('click', toggleCell);
            board.appendChild(cell);
        }
    }
}

function toggleCell(event) {
    const clickedCell = event.target;
    clickedCell.classList.toggle('clicked');
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

generateRandomBoard();  // Initial board generation
